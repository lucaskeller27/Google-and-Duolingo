import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    
    <View style={styles.container}>
    <img src="https://1000logos.net/wp-content/uploads/2020/10/Duolingo-logo.png" style={styles.duologo}></img>
      <Text style={styles.paragraph}>
      Learn a language for free.
      Forever.
      </Text>
      <View>
      <Card>
      <button type="button" class="buttonOne" style={styles.buttonOne}>GET STARTED</button>
      <button type="button" class="buttonTwo" style={styles.buttonTwo}>I ALREADY HAVE AN ACCOUNT</button>
      </Card>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  duologo: {
    padding: 80,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#FFFFF',
    padding: 30,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'gray',
    fontFamily: 'Arial',
  },
  buttonOne: {
    padding: 15,
    borderradius: 50,
    backgroundColor: '#649900',
  },
  buttonTwo: {
    padding: 15,
  },
});
