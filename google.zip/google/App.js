import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import { Header } from 'react-native';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.header}>
  <img src="https://cdn-icons-png.flaticon.com/512/3566/3566345.png"></img>
  <img src="https://cdn2.iconfinder.com/data/icons/50-material-design-round-corner-style/44/Submenu_2-512.png"></img>
    </View>,
    <View>
    </View>,
    <View style={styles.container}>
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2560px-Google_2015_logo.svg.png" style={styles.googlelogo}></img>
      <input type="search" placeholder="Search or type URL" style={styles.searchbar}></input>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'White',
    padding: 8,
  },
  header: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'White',
    padding: 8,
  },
  googlelogo: {
    padding: 30,
  },
  searchbar: {
    padding: 10,
    margin: 60,
    
  }
});
